import { Component, OnInit } from '@angular/core';
import { IProduct } from './product';
import { ProductService } from './product.service';

@Component({ 
    selector: 'app-products',
    templateUrl : './product-list.component.html',
    styles : ['thead{color:#337AB7}']
})
export class ProductListComponent implements OnInit  {
    
    pageTitle = 'Product List';
    imageWidth: number = 50;
    imageMargin: number = 2;
    showImage : boolean = false;
    _filter: string;
    get filter(): string {
        return this._filter;
    }
    set filter(value : string) {
        this._filter = value;
        this.filteredProducts = this._filter ? this.performFilter(this._filter) : this.products;
    }
    filteredProducts : IProduct[];
    products : IProduct[];

    constructor(private productService: ProductService) {
        this.filter = '';
    }

    ngOnInit(): void {
        this.products = this.productService.getProducts();
        this.filteredProducts = this.products;
    }

    toggleImage() : void {
        this.showImage = !this.showImage;
    }

    performFilter(filterBy: string) : IProduct[] {
        filterBy = filterBy.toLocaleLowerCase();
        return this.products.filter((product : IProduct) => 
            product.productName.toLocaleLowerCase().indexOf(filterBy) !== -1);
    }

    onRatingClicked(message: string) : void {
        this.pageTitle = 'Product List : ' + message;
    }
}