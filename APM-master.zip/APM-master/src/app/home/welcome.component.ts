import { Component } from '@angular/core';
@Component({
    selector: 'app-home',
    templateUrl : './welcome.component.html'
})
export class WelcomeComponent {
    public pageTitle = 'Welcome';
}